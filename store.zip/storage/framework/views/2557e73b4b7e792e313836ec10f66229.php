

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="mb-4">Welcome to Our E-commerce Store</h1>

    <div>
        <h2>Featured Products</h2>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($product['name']); ?></h3>
                    <p class="card-text">Price: $<?php echo e($product['price']); ?></p>
                    
                    
                    
                        
                        <button type="submit" class="btn btn-primary">Add to Cart</button>
                    
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\store\resources\views/home.blade.php ENDPATH**/ ?>